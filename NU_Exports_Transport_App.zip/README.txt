NU EXPORTS TRANSPORT APP

Features:
- LR Number
- Transport Name
- Number of Articles
- Freight Amount
- Local Freight
- Booking Date
- Delivery Date
- Status
- Save / Update / Clear / Delete
- Total parcels and Pending parcels dashboard
- Automatic Total = Freight + Local Freight
- Data is saved on the phone browser using localStorage

IMPORTANT:
This is a mobile-friendly web app. Open index.html in a browser.
For a true Android APK, this web app can later be wrapped into an APK.
